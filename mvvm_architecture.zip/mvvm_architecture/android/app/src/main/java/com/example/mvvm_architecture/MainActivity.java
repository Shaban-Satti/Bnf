package com.example.mvvm_architecture;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
