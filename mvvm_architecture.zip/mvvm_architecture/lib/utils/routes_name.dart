class RouteName{
  static const String login='login_screen';
  static const String signUp='signup_screen';
  static const String home='home_screen';
  static const String  splash='Splash_view';

}