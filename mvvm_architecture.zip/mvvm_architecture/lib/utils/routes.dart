import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:mvvm_architecture/utils/routes_name.dart';
import 'package:mvvm_architecture/view/Splash_view.dart';
import 'package:mvvm_architecture/view/home_screen.dart';
import 'package:mvvm_architecture/view/login_screen.dart';
import 'package:mvvm_architecture/view/signup_screen.dart';

class Routes{
  static Route<dynamic> generateRoute(RouteSettings settings)
  {
    switch(settings.name){

      case RouteName.splash:
        return MaterialPageRoute(builder: (BuildContext context)=>SplashView());

      case RouteName.home:
        return MaterialPageRoute(builder: (BuildContext context)=>HomeScreen());
      case RouteName.login:
        return MaterialPageRoute(builder: (BuildContext context)=>LoginScreen());
      case RouteName.signUp:
        return MaterialPageRoute(builder: (BuildContext context)=>SignUp());

        default:
        return MaterialPageRoute(builder: (_){
          return Scaffold(
            body: Center(
              child: Text('No Rout Define'),

            ),
          );
        });
    }
  }
}