class model {
  String? status;
  Result? result;
  String? token;

  model({this.status, this.result, this.token});

  model.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    result =
    json['result'] != null ? new Result.fromJson(json['result']) : null;
    token = json['token'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.result != null) {
      data['result'] = this.result!.toJson();
    }
    data['token'] = this.token;
    return data;
  }
}

class Result {
  int? id;
  String? username;
  String? fName;
  String? email;
  Null? country;
  String? pnumber;
  String? deposit;
  String? totalInvestment;
  Null? prId;
  Null? emailVerifiedAt;
  String? coin;
  String? usd;
  String? tradeUsd;
  String? tradeCoins;
  String? holdingUsd;
  String? status;
  String? profilePic;
  String? createdAt;
  String? updatedAt;

  Result(
      {this.id,
        this.username,
        this.fName,
        this.email,
        this.country,
        this.pnumber,
        this.deposit,
        this.totalInvestment,
        this.prId,
        this.emailVerifiedAt,
        this.coin,
        this.usd,
        this.tradeUsd,
        this.tradeCoins,
        this.holdingUsd,
        this.status,
        this.profilePic,
        this.createdAt,
        this.updatedAt});

  Result.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    username = json['username'];
    fName = json['f_name'];
    email = json['email'];
    country = json['country'];
    pnumber = json['pnumber'];
    deposit = json['deposit'];
    totalInvestment = json['total_investment'];
    prId = json['pr_id'];
    emailVerifiedAt = json['email_verified_at'];
    coin = json['coin'];
    usd = json['usd'];
    tradeUsd = json['trade_usd'];
    tradeCoins = json['trade_coins'];
    holdingUsd = json['holding_usd'];
    status = json['status'];
    profilePic = json['profile_pic'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['username'] = this.username;
    data['f_name'] = this.fName;
    data['email'] = this.email;
    data['country'] = this.country;
    data['pnumber'] = this.pnumber;
    data['deposit'] = this.deposit;
    data['total_investment'] = this.totalInvestment;
    data['pr_id'] = this.prId;
    data['email_verified_at'] = this.emailVerifiedAt;
    data['coin'] = this.coin;
    data['usd'] = this.usd;
    data['trade_usd'] = this.tradeUsd;
    data['trade_coins'] = this.tradeCoins;
    data['holding_usd'] = this.holdingUsd;
    data['status'] = this.status;
    data['profile_pic'] = this.profilePic;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}
