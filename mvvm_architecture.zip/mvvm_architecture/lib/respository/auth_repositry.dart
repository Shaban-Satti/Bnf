
import 'package:mvvm_architecture/data/network/BaseApiServices.dart';
import 'package:mvvm_architecture/res/app_url.dart';

import '../data/network/NetworkApiServices.dart';

class AuthRepositry{
  BaseApiService _apiService=  NetworkApiServices();
  Future<dynamic> loginApi(dynamic data) async{
    try{
      dynamic response=await _apiService.getPostApiResponse(AppUrl.loginUrl,data) ;
      return response;
    }
        catch(e){
      throw e;
        }
  }

  Future<dynamic> SignUpApi(dynamic data) async{
    try{
      dynamic response=await _apiService.getPostApiResponse(AppUrl.singupUrl,data) ;
      return response;
    }
    catch(e){
      throw e;
    }
  }

}