import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:mvvm_architecture/respository/auth_repositry.dart';
import 'package:mvvm_architecture/utils/routes_name.dart';
import 'package:mvvm_architecture/utils/utils.dart';
import 'package:mvvm_architecture/view/home_screen.dart';

class AuthViewModel with ChangeNotifier {
  final _myRepo = AuthRepositry();
  bool _loading = false;
  bool get loading => _loading;
  bool _signUpLoading=false;
  bool get signUpLoading => _signUpLoading;

  _setLoading(bool value) {
    _loading = value;
    notifyListeners();
  }

  _setSignUpLoading(bool value) {
    _signUpLoading = value;
    notifyListeners();
  }

  Future<void> loginApi(dynamic data, BuildContext context) async {
    _setLoading(true);
    _myRepo.loginApi(data).then((value) {
      _setLoading(false);
      Navigator.pushNamed(context, RouteName.home);
      Utils.flashBarErrorMessage('Login Successfully'.toString(), context);
      if (kDebugMode) {
        print(value.toString());
      }
    }).onError((error, stackTrace) {
      _setLoading(false);
      if (kDebugMode) {
        Utils.flashBarErrorMessage(error.toString(), context);
        print(error.toString());
      }
    });
  }

  Future<void> SignUpApi(dynamic data, BuildContext context) async {
    _setSignUpLoading(true);
    _myRepo.SignUpApi(data).then((value) {
      _setSignUpLoading(false);
      Navigator.pushNamed(context, RouteName.home);
      Utils.flashBarErrorMessage('Sign Up Successfully'.toString(), context);
      if (kDebugMode) {
        print(value.toString());
      }
    }).onError((error, stackTrace) {
      _setSignUpLoading(false);
      if (kDebugMode) {
        Utils.flashBarErrorMessage(error.toString(), context);
        print(error.toString());
      }
    });
  }

}
