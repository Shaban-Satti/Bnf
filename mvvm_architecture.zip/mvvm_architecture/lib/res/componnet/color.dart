import 'package:flutter/material.dart';

class AppColor{
  static const Color blackColor=Color(0xff0000);
  static const Color whiteColor=Color(0xffffffff);
  static const Color buttonColor=Colors.green;
}