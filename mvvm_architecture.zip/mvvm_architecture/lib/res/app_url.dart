class AppUrl{
  static var baseUrl='https://https://reqres.in';
  static var loginUrl='https://desireexchange.com/api/login';
  static var singupUrl=baseUrl+'/api/register';

}