import 'package:flutter/material.dart';
import 'package:mvvm_architecture/utils/routes_name.dart';
import 'package:provider/provider.dart';

import '../res/componnet/round_button.dart';
import '../utils/utils.dart';
import '../view_model/auth_view_model.dart';
class SignUp extends StatefulWidget {
  const SignUp({super.key});

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  ValueNotifier<bool> _obsecurePasword = ValueNotifier<bool>(true);
  TextEditingController _email = TextEditingController();
  TextEditingController _pasword = TextEditingController();
  FocusNode emailFocusNode = FocusNode();
  FocusNode passwordFocusNode = FocusNode();
  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    _email.dispose();
    _pasword.dispose();
    emailFocusNode.dispose();
    passwordFocusNode.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authViewModel = Provider.of<AuthViewModel>(context);
    final _height = MediaQuery.of(context).size.height * 1;
    return Scaffold(
        appBar: AppBar(
          title: const Text('SignUp'),
          centerTitle: true,
        ),
        body: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              TextFormField(
                controller: _email,
                keyboardType: TextInputType.emailAddress,
                focusNode: emailFocusNode,
                decoration: const InputDecoration(
                  hintText: 'Email',
                  labelText: 'Email',
                  prefixIcon: Icon(Icons.alternate_email),
                ),
                onFieldSubmitted: (value) {
                  Utils.fieldFocusChange(
                      context, emailFocusNode, passwordFocusNode);
                },
              ),
              ValueListenableBuilder(
                  valueListenable: _obsecurePasword,
                  builder: (context, value, child) {
                    return TextFormField(
                      controller: _pasword,
                      obscureText: _obsecurePasword.value,
                      obscuringCharacter: '*',
                      focusNode: passwordFocusNode,
                      decoration: InputDecoration(
                          hintText: 'Password',
                          labelText: 'Password',
                          prefixIcon: Icon(Icons.lock),
                          suffixIcon: InkWell(
                              onTap: () {
                                _obsecurePasword.value =
                                !_obsecurePasword.value;
                              },
                              child: Icon(_obsecurePasword.value
                                  ? Icons.visibility_off_outlined
                                  : Icons.visibility))),
                    );
                  }),
              SizedBox(
                height: _height * .085,
              ),
              RoundButton(
                title: 'SignUp',
                loading: authViewModel.signUpLoading,
                onPress: () {
                  if (_email.text.isEmpty) {
                    Utils.flashBarErrorMessage('Please Enter Email', context);
                  } else if (_pasword.text.isEmpty) {
                    Utils.flashBarErrorMessage('Please Enter Pasword', context);
                  } else if (_pasword.text.length < 6) {
                    Utils.flashBarErrorMessage(
                        'Please Enter 6 digit Pasword', context);
                  } else {
                    Map data = {
                      'email': _email.text.toString(),
                      'password': _pasword.text.toString(),
                    };
                    authViewModel.SignUpApi(data, context);
                    print('api hit');
                  }
                },
              ),
              SizedBox(height: _height * .02),
              InkWell(
                  onTap: () {
                    Navigator.pushNamed(context, RouteName.login);
                  },
                  child: const Text("Already  have an account? Login"))
            ],
          ),
        ));
  }
} 