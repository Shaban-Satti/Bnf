import 'dart:convert';
import 'package:http/http.dart'as http;
import 'login_screen.dart';
var result;
var dataa1;
Future<void> getTotal()async{
  String key=data['result']['id'].toString();
  String token=data['token'];
  final response=await http.get(Uri.parse('https://desireexchange.com/api/total/mining?uid=${key}') ,
    headers: {
 // HttpHeaders.authorizationHeader:token,
      'Content-Type':'application/json;charset=UTF-8',
     'Authorization':'Bearer $token'


  },);
  //print(response.body);
  if(response.statusCode==201){
    result=jsonDecode(response.body.toString());
    //print(result['current_mining'].toString());

  }
  else{

  }
}

Future<void>PostMining()async{
  var data;
  String key=data['result']['id'].toString();
  final response=await http.post(Uri.parse('https://desireexchange.com/api/mining?uid=uid=${key}&coins=2'));
  //print(response.body);
  if(response.statusCode==201){
    data=jsonDecode(response.body.toString());
   // print(result['current_mining'].toString());

  }
  else{

  }
}


Future<void> getdetail()async{
  String key=data['result']['id'].toString();
  String token=data['token'];
  final response=await http.get(Uri.parse('https://desireexchange.com/api/dashborad?uid=${key}'),
      headers: {
  'Content-Type':'application/json;charset=UTF-8',
  'Authorization':'Bearer $token'


  });

  if(response.statusCode==201){
     dataa1=jsonDecode(response.body.toString());
   // print(dataa1);

  }
  else{
    print('Failed');

  }


}
