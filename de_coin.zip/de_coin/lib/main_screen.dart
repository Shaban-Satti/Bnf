import 'package:de_coin/api_calling.dart';
import 'package:de_coin/miner_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animated_button/flutter_animated_button.dart';
import 'package:share_plus/share_plus.dart';
import 'login_screen.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff121325),
      appBar: AppBar(
        backgroundColor: const Color(0xff121325),
        centerTitle: true,
        title: const Text(
          'Dcoin APP',
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            UserAccountsDrawerHeader(
              // <-- SEE HERE
              decoration: const BoxDecoration(color:  Color(0xff121325)),
              accountName: Text(data['result']['username'].toString()),
              accountEmail: Text(data['result']['email'].toString()),
              currentAccountPicture:
                  const Image(image: AssetImage('images/decoin.png')),
            ),
            const SizedBox(
              height: 50,
            ),
            ListTile(
              leading: const Icon(
                Icons.logout,
              ),
              title: const Text('Log Out'),
              onTap: () {
                setState(() {
                  Navigator.pushReplacement(context,
                      MaterialPageRoute(builder: (context) => LogInScreen()));
                });
              },
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              FutureBuilder<void>(
                  future: getdetail(),
                  builder: (BuildContext context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(
                        child: CircularProgressIndicator(),
                      );
                    } else {
                      return Padding(
                        padding: const EdgeInsets.all(10),
                        child: Card(
                          color: const Color(0xff121325),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10.0),
                            side:const  BorderSide(
                              color: Colors.white,
                            ),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                        child: ReUse(
                                            title: 'Deposit',
                                            value: dataa1['data']['deposit']
                                                .toString(),
                                            icon: Icons.account_balance)),
                                    Expanded(
                                        child: ReUse(
                                            title: 'Total Allocated Coin',
                                            value: dataa1['data']['coin']
                                                .toString(),
                                            icon: Icons.currency_bitcoin)),
                                  ],
                                ),
                                Row(
                                  children: [
                                    Expanded(
                                        child: ReUse(
                                            title: 'Total Investment',
                                            value: dataa1['data']
                                                    ['total_investment']
                                                .toString(),
                                            icon: Icons.account_box)),
                                    Expanded(
                                        child: ReUse(
                                            title: 'Trade USD',
                                            value: dataa1['data']['trade_usd']
                                                .toString(),
                                            icon: Icons.trending_up)),
                                  ],
                                ),
                                Row(
                                  children: [
                                    Expanded(
                                        child: ReUse(
                                            title: 'Trade Coin',
                                            value: dataa1['data']['trade_coins']
                                                .toString(),
                                            icon: Icons
                                                .account_balance_wallet_sharp)),
                                    Expanded(
                                        child: ReUse(
                                            title: 'Coin Price',
                                            value: dataa1['coin'].toString(),
                                            icon: Icons.upcoming)),
                                  ],
                                )
                              ],
                            ),
                          ),
                        ),
                      );
                    }
                  }),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(
                      height: 50,
                    ),
                    AnimatedButton(
                      height: 50,
                      width: 160,
                      text: 'Share',

                      isReverse: true,
                      selectedTextColor: Colors.black,
                      transitionType: TransitionType.LEFT_TO_RIGHT,
                      textStyle: const TextStyle(
                          fontSize: 18,
                          color: Colors.white,
                          fontWeight: FontWeight.bold),
                      borderColor: Colors.white,
                      borderRadius: 10,
                      borderWidth: 2,
                      onPress: () {
                        Share.share('https://desireexchange.com/');

                        /*Clipboard.setData(
                            ClipboardData(text: "https://desireexchange.com/"));

                        Fluttertoast.showToast(
                            msg: 'Link Copied',
                            toastLength: Toast.LENGTH_SHORT);*/

                        // launch('https://desireexchange.com/');
                      },
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    AnimatedButton(
                      height: 50,
                      width: 160,
                      text: 'Start Mining',
                      isReverse: true,
                      selectedTextColor: Colors.black,
                      transitionType: TransitionType.LEFT_TO_RIGHT,
                      textStyle: const TextStyle(
                          fontSize: 18,
                          color: Colors.white,
                          fontWeight: FontWeight.bold),
                      borderColor: Colors.white,
                      borderRadius: 10,
                      borderWidth: 2,
                      onPress: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const MinerScreen()));
                      },
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

class ReUse extends StatelessWidget {
  final String title, value;
  final IconData icon;
  const ReUse({required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Padding(
            padding: const EdgeInsets.all(4.0),
            child: Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: const BorderSide(
                  color: Colors.white,
                ),
              ),
              elevation: 50,
              shadowColor: Colors.white,
              color: const Color(0xff121325),
              child: SizedBox(
                width: 250,
                height: 180,
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    children: [
                      CircleAvatar(
                        backgroundColor: Colors.white,
                        radius: 30,
                        child: Icon(icon, size: 40, color: const Color(0xff121325)),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Text(
                        title.toString(),
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, color: Colors.white),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Text(
                        value,
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, color: Colors.white),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
