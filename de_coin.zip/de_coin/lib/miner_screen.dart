import 'package:flutter/material.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'dart:async';
import 'api_calling.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

class MinerScreen extends StatefulWidget {
  const MinerScreen({Key? key}) : super(key: key);

  @override
  State<MinerScreen> createState() => _MinerScreenState();
}

class _MinerScreenState extends State<MinerScreen> {

  // Step 2
  double percent = 0.0;
  Timer? countdownTimer;
  Duration myDuration = Duration(days: 2);
  @override
  void initState() {
    Timer ? timer;
    timer = Timer.periodic(Duration(milliseconds:1000),(_){
      percent+=1;
      setState(() {

        if(percent >= 120000){
          timer!.cancel();
          // percent=0;
        }
      });
    });
    super.initState();
  }


  /// Timer related methods ///
  // Step 3
  void startTimer() {
    countdownTimer =
        Timer.periodic(Duration(seconds: 1), (_) => setCountDown());
  }
  void stopTimer() {
    setState(() => countdownTimer!.cancel());
  }
  void resetTimer() {
    stopTimer();
    setState(() => myDuration = Duration(seconds: 1));
  }
  void setCountDown()  {
    setState(() {

    });

    final reduceSecondsBy = 1;


     final seconds = myDuration.inSeconds - reduceSecondsBy;
     // final seconds = prefs.getInt(myDuration.inSeconds! - reduceSecondsBy!) ?? 0;

      if (seconds < 0) {
        countdownTimer!.cancel();

        FutureBuilder(
          future: PostMining(),
          builder: (context,snapshot){
            return const Center(child: Text('Coin Add',style: TextStyle(color: Colors.green,fontSize: 50)));

          },);
      } else {
        myDuration = Duration(seconds: seconds);
      }

  }
  @override
  Widget build(BuildContext context) {
    String strDigits(int n) => n.toString().padLeft(2, '0');

    final hours = strDigits(myDuration.inHours.remainder(2));
    final minutes = strDigits(myDuration.inMinutes.remainder(60));
    final seconds = strDigits(myDuration.inSeconds.remainder(60));
    return SafeArea(child: Scaffold(
     // backgroundColor:  const Color(0xff121325),
      appBar: AppBar(title: Text("Dcoin Miner"),
      centerTitle: true,
        backgroundColor:  const Color(0xff121325),),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              decoration: BoxDecoration(
                borderRadius:BorderRadius.circular(15),
                color:const  Color(0xff121325)
              ),
              height: 400,
              width: 400,
              child:Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(15.0),
                    child:  CircularPercentIndicator(
                      radius: 120.0,
                      animation: true,

                      animationDuration: 1200,
                      lineWidth: 15.0,
                      percent: percent/1200,
                      center:   Text(
                        '$hours:$minutes:$seconds',
                        style:
                        const TextStyle(fontWeight: FontWeight.bold, fontSize: 20.0,color: Colors.white),
                      ),
                      circularStrokeCap: CircularStrokeCap.butt,
                      backgroundColor: Colors.white,
                      progressColor: Colors.white,
                    ),
                  ),




                  const SizedBox(height: 20),
                ],
              ) ,
            ),
          ),
          InkWell(
            onTap: (){
              getTotal();

              if(countdownTimer == null){
                startTimer();
              }
               else
                 if(countdownTimer!.isActive){
                stopTimer();
              }
                 else
                 if(countdownTimer!.isActive&&countdownTimer != null){
                   resetTimer();
                   setState(() {

                   });
                 }


            },

            child: Container(
              height: 60,
              width: 400,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color :Color(0xff121325)),
              child: Center(child: countdownTimer == null? const Text(
                'Acitivate',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),): countdownTimer!.isActive?
              const Text(
                'Pause',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),):const Text(
                'Go To BackPage',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),)),

            ),
          ),



          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              decoration: BoxDecoration(
                  borderRadius:BorderRadius.circular(15),
                  color: const Color(0xff121325)
              ),
              height: 100,
              width: 400,
              child:Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Expanded(
                      child: ListView.builder(
                                  itemCount: 1,
                                  itemBuilder: (context,index) {
                                    return
                                      Padding(padding: const EdgeInsets.all(10),
                                          child: Column(
                                            children: [
                                             ReUseAble(title: 'Current Mining', value:result['current_mining'].toString()),
                                              const Divider(
                                                color: Colors.grey,
                                              ),
                                              ReUseAble(title: 'Total Mining', value:result['total_mining'].toString()),

                                            ],
                                          )

                                      );



                          }
                    ),
                    ),



                  ],
                ),
              ) ,
            ),
          ),
          GestureDetector(
            onTap: (){
              Alert(
                  type: AlertType.success,context: context, title: "Congrulation", desc: "You Collect The Reward").show();

            },
            child: Container(
              height: 40,
              width: 90,
              decoration: BoxDecoration(
                  color: const Color(0xff121325),
                borderRadius:BorderRadius.circular(10),
              ),
              child: const Center(child: Text('Collect',style: TextStyle(fontWeight: FontWeight.bold,color: Colors.white),),),
            ),
          ),


    ],
      ),
    ),
    );
  }
}
class ReUseAble extends StatelessWidget {
  final String title,value;
  const ReUseAble({required this.title,required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      mainAxisSize: MainAxisSize.max,
      children: [
        Text(title.toString(),style:const  TextStyle(fontWeight: FontWeight.bold,color: Colors.white),),
        Text(value,style: const TextStyle(fontWeight: FontWeight.bold,color: Colors.white),),

      ],
    );
  }
}

