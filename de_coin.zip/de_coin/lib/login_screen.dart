import 'dart:convert';
import 'package:de_coin/main_screen.dart';
import 'package:de_coin/sign_up.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

var data;
class LogInScreen extends StatefulWidget {
  const LogInScreen({Key? key}) : super(key: key);
  @override
  State<LogInScreen> createState() => _LogInScreenState();
}

class _LogInScreenState extends State<LogInScreen> {
  TextEditingController emailcontroller=TextEditingController();
  TextEditingController passwordcontroller=TextEditingController();

  void login(String email,var password)async{
    try{
      Response response=await post(
          Uri.parse('https://desireexchange.com/api/login'),
          body:{
            'email':email,
            'password':password,
          }
      );
      if(response.statusCode==201){
         data=jsonDecode(response.body.toString());
       // print(data);

         Navigator.push(context, MaterialPageRoute(builder: (context)=> MainScreen()),);
      }
      else{
        print('Failed');
        Alert(
            type: AlertType.warning,context: context, title: "Opps", desc: "Re Enter Email & Password").show();


      }
    }
    catch(e){
      print(e.toString());
    }

  }
  ValueNotifier<bool> _toggle=ValueNotifier<bool>(false);
  @override
  Widget build(BuildContext context) {
    return  
      Scaffold(
        //backgroundColor: Color(0xff121325),
      appBar: AppBar(
        leading:const Image(image: AssetImage('images/decoin.png',),width: 180,
            height: 150,
            fit:BoxFit.fill),
        title: const Text('Dcoin',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 25),),
        centerTitle: true,
        backgroundColor:const Color(0xff121325),
      ),
      body:SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 30,vertical: 100),
          child: Column(
            children: [
              const Center(
                child: Image(image: AssetImage('images/decoin.png',),width: 200,
                    height: 200,
                    fit:BoxFit.fill),
              ) ,
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Card(
                  color: const Color(0xff121325),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15.0),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [

                        TextFormField(
                          controller: emailcontroller,
                          keyboardType: TextInputType.emailAddress,
                          decoration:InputDecoration(

                            hintText: 'Email',
                            labelText: 'Email',
                            labelStyle:const TextStyle(color: Colors.white),
                            fillColor: Colors.blueGrey,//(0xffbf9fa),
                            filled: true ,
                            prefixIcon: const Icon(
                              Icons.email,
                              color: Colors.white,//(0xff323f4b ),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: const BorderSide(color: Color(0xffe4e7eb)),
                              borderRadius: BorderRadius.circular(10),)
                            ,
                            enabledBorder: OutlineInputBorder(
                              borderSide: const BorderSide(color: Color(0xffe4e7eb)),
                              borderRadius: BorderRadius.circular(10),),),

                        ),

                        const SizedBox(
                          height: 10,
                        ),

                        ValueListenableBuilder(
                            valueListenable: _toggle,
                            builder: (context,value,child){
                              return TextFormField(

                                controller: passwordcontroller,
                                obscureText: _toggle.value,
                                decoration: InputDecoration(

                                      hintText: 'Password',
                                      labelText: 'Password',
                                      labelStyle:const TextStyle(color: Colors.white),
                                      fillColor: Colors.blueGrey,//(0xffbf9fa),
                                      filled: true ,
                                      prefixIcon: const Icon(
                                        Icons.lock,
                                        color: Colors.white,//(0xff323f4b ),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: const BorderSide(color: Color(0xffe4e7eb)),
                                        borderRadius: BorderRadius.circular(10),),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: const BorderSide(color: Color(0xffe4e7eb)),
                                        borderRadius: BorderRadius.circular(10),),
                                    suffix: InkWell(onTap: (){
                                      _toggle.value=!_toggle.value;
                                    },
                                        child: Icon(_toggle.value? Icons.visibility_off_outlined:Icons.visibility),)
                                ),
                              );
                            }),

                        const  SizedBox(
                          height: 20,
                        ),
                        GestureDetector(
                          onTap: (){

                            login(emailcontroller.text.toString(),passwordcontroller.text.toString());
                          },
                          child: Container(
                            height: 50,
                            decoration: BoxDecoration(
                              color: Colors.blueGrey,
                              borderRadius:BorderRadius.circular(10),
                            ),
                            child: const Center(child: Text('Log In',style: TextStyle(fontWeight: FontWeight.bold),),),
                          ),
                        ),
                        InkWell(
                          onTap: (){
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>SignUp()));
                          },
                          child: Container(
                            child:   const  Padding(
                              padding:  EdgeInsets.only(top: 20,left: 80),
                              child: Text("Dn't have any account ?\ Sign Up",style: TextStyle(color: Colors.white),),
                            ),
                          ),
                        )

                      ],
                    ),
                  ),
                ),
              ),





            ],
          ),
        )
      ),

      );


  }
}
