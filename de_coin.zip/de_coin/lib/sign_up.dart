import 'dart:convert';
import 'package:de_coin/main_screen.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart';
class SignUp extends StatefulWidget {
  const SignUp({Key? key}) : super(key: key);

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  TextEditingController namecontroller=TextEditingController();
  TextEditingController usernamecontroller=TextEditingController();
  TextEditingController emailcontroller=TextEditingController();
  TextEditingController mblnumbercontroller=TextEditingController();
  TextEditingController passwordcontroller=TextEditingController();
  TextEditingController confirmpasswordcontroller=TextEditingController();
  void singup(String name,String username,String email,String number,String password,String confirmpassword)async{
    try{
      Response response=await post(
          Uri.parse('https://desireexchange.com/api/register'),
          body:{
            'name':name,
            'username':username,
            'email':email,
            'phone_number':number,
            'password':password,
            'password_confirmation':confirmpassword,
          }
      );
      if(response.statusCode==201){
        Map<String, dynamic> data=jsonDecode(response.body.toString());
        Navigator.push(context, MaterialPageRoute(builder: (context)=>MainScreen()));
        Fluttertoast.showToast(msg: 'Account Created Sussesfully',toastLength:
        Toast.LENGTH_SHORT);
      }
      else{
        Fluttertoast.showToast(msg: 'Failed',toastLength:
        Toast.LENGTH_SHORT,backgroundColor: Colors.red,);

      }
    }
    catch(e){
      print(e.toString());
    }

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Sign Up'),
      centerTitle: true,
        backgroundColor:  const Color(0xff121325),
      ),
      body:
      SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 30,vertical: 100),
            child: Column(
              children: [

                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  child: Card(
                    color: const Color(0xff121325),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15.0),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          TextFormField(
                            controller: namecontroller,
                            decoration:InputDecoration(

                              hintText: 'Name',
                              labelText: ' Name',
                              labelStyle:const TextStyle(color: Colors.white),
                              fillColor: Colors.blueGrey,//(0xffbf9fa),
                              filled: true ,
                              prefixIcon: const Icon(
                                Icons.person,
                                color: Colors.white,//(0xff323f4b ),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: const BorderSide(color: Color(0xffe4e7eb)),
                                borderRadius: BorderRadius.circular(10),)
                              ,
                              enabledBorder: OutlineInputBorder(
                                borderSide: const BorderSide(color: Color(0xffe4e7eb)),
                                borderRadius: BorderRadius.circular(10),),),
                          ),
                          const SizedBox(
                            height: 10,
                          ),

                          TextFormField(
                            controller: usernamecontroller,
                            decoration:InputDecoration(

                              hintText: 'User Name',
                              labelText: 'User Name',
                              labelStyle:const TextStyle(color: Colors.white),
                              fillColor: Colors.blueGrey,//(0xffbf9fa),
                              filled: true ,
                              prefixIcon: const Icon(
                                Icons.person,
                                color: Colors.white,//(0xff323f4b ),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: const BorderSide(color: Color(0xffe4e7eb)),
                                borderRadius: BorderRadius.circular(10),)
                              ,
                              enabledBorder: OutlineInputBorder(
                                borderSide: const BorderSide(color: Color(0xffe4e7eb)),
                                borderRadius: BorderRadius.circular(10),),),
                          ),
                         const SizedBox(
                            height: 10,
                          ),
                          TextFormField(
                            controller: emailcontroller,
                            keyboardType: TextInputType.emailAddress,
                            decoration:InputDecoration(

                              hintText: 'Email',
                              labelText: 'Email',
                              labelStyle:const TextStyle(color: Colors.white),
                              fillColor: Colors.blueGrey,//(0xffbf9fa),
                              filled: true ,
                              prefixIcon: const Icon(
                                Icons.email,
                                color: Colors.white,//(0xff323f4b ),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: const BorderSide(color: Color(0xffe4e7eb)),
                                borderRadius: BorderRadius.circular(10),)
                              ,
                              enabledBorder: OutlineInputBorder(
                                borderSide: const BorderSide(color: Color(0xffe4e7eb)),
                                borderRadius: BorderRadius.circular(10),),),

                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          TextFormField(
                            controller: mblnumbercontroller,
                            decoration:InputDecoration(

                              hintText: 'Mobile Number',
                              labelText: 'Mobile Number',
                              labelStyle:const TextStyle(color: Colors.white),
                              fillColor: Colors.blueGrey,//(0xffbf9fa),
                              filled: true ,
                              prefixIcon: const Icon(
                                Icons.person_add,
                                color: Colors.white,//(0xff323f4b ),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: const BorderSide(color: Color(0xffe4e7eb)),
                                borderRadius: BorderRadius.circular(10),)
                              ,
                              enabledBorder: OutlineInputBorder(
                                borderSide: const BorderSide(color: Color(0xffe4e7eb)),
                                borderRadius: BorderRadius.circular(10),),),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          TextFormField(
                            controller: passwordcontroller,
                            decoration:InputDecoration(

                              hintText: 'Password',
                              labelText: 'Password',
                              labelStyle:const TextStyle(color: Colors.white),
                              fillColor: Colors.blueGrey,//(0xffbf9fa),
                              filled: true ,
                              prefixIcon: const Icon(
                                Icons.lock,
                                color: Colors.white,//(0xff323f4b ),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: const BorderSide(color: Color(0xffe4e7eb)),
                                borderRadius: BorderRadius.circular(10),)
                              ,
                              enabledBorder: OutlineInputBorder(
                                borderSide: const BorderSide(color: Color(0xffe4e7eb)),
                                borderRadius: BorderRadius.circular(10),),),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          TextFormField(
                            controller: confirmpasswordcontroller,
                            decoration:InputDecoration(

                              hintText: 'Confirm Password',
                              labelText: 'Confirm Password',
                              labelStyle:const TextStyle(color: Colors.white),
                              fillColor: Colors.blueGrey,//(0xffbf9fa),
                              filled: true ,
                              prefixIcon: const Icon(
                                Icons.lock,
                                color: Colors.white,//(0xff323f4b ),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: const BorderSide(color: Color(0xffe4e7eb)),
                                borderRadius: BorderRadius.circular(10),)
                              ,
                              enabledBorder: OutlineInputBorder(
                                borderSide: const BorderSide(color: Color(0xffe4e7eb)),
                                borderRadius: BorderRadius.circular(10),),),
                          ),

                         const  SizedBox(
                            height: 20,
                          ),
                          GestureDetector(
                            onTap: (){
                     singup(namecontroller.text.toString(),usernamecontroller.text.toString(),
                       emailcontroller.text.toString(),mblnumbercontroller.text.toString(),
                         passwordcontroller.text.toString(), confirmpasswordcontroller.text.toString());
    },
                            child: Container(
                              height: 50,
                              decoration: BoxDecoration(
                                color: Colors.blueGrey,
                                borderRadius:BorderRadius.circular(10),
                              ),
                              child: const Center(child: Text('Sign Up',style: TextStyle(fontWeight: FontWeight.bold),),),
                            ),
                          ),

                        ],
                      ),
                    ),
                  ),
                ),

              ],
            ),
          )
      )
    );
  }
}
