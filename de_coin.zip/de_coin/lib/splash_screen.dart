import 'dart:async';
import 'package:de_coin/login_screen.dart';
import 'package:flutter/material.dart';
import 'dart:math'as math;
import 'package:simple_gradient_text/simple_gradient_text.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>with TickerProviderStateMixin {
  late final AnimationController _controller=AnimationController(
      duration: const Duration(seconds: 3),
      vsync: this)..repeat();
  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    _controller.dispose();
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Timer(const Duration(seconds: 3), () {
      Navigator.push(context, MaterialPageRoute(builder: (context)=>const LogInScreen()));//LogInScreen()
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
backgroundColor: const Color(0xff121325),
      body: SafeArea(
        child: Column(

          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            AnimatedBuilder(
                animation: _controller,
                child: Container(
                  width: 200,
                  height: 200,
                  child: const Center(
                    child: Image(image: AssetImage('images/decoin.png')),
                  ),
                ),
                builder: (BuildContext context , Widget?child)
                {
                  return
                    Transform.rotate(
                    angle: _controller.value*2.0*math.ln2,
                    child:child ,);
                })
            ,
           const  SizedBox(
              //height: MediaQuery.of(context).size.height*.08,
              height: 10,
            ),
             Align (
                alignment: Alignment.center,
                child:
              GradientText(
              'Welcome To \n Decoin',
                textAlign: TextAlign.center,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 25.0,
              ),
              colors: const [
                Colors.blue,
                Colors.red,
                Colors.teal,
              ],
            ),
            )
          ],
        ),
      ),

    );
  }
}
