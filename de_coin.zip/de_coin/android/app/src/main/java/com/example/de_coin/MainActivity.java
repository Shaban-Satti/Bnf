package com.example.de_coin;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
